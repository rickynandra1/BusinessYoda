package in.businessyoda.businessyoda;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;

import java.util.ArrayList;

/**
 * Created by Ricky Nandra on 02/12/18.
 * All the SQLite functionality is present in this file
 */

public class BYSQLiteOpenHelper extends SQLiteOpenHelper {
    private static final int VERSION = 1;
    public static final String DB_NAME = "BusinessYoda.db";
    public static final String BUSINESS_TABLE = "Business";
    public static final String USER_TABLE = "User";

    private static final String CREATE_BUSINESS_TABLE_QUERY = "CREATE TABLE "+BUSINESS_TABLE+"  ( id INTEGER PRIMARY KEY, name  TEXT, description  TEXT, website  TEXT, latitude  INTEGER, longitude  INTEGER , facebook_url  TEXT,  address  TEXT,timings  TEXT,phone_number  TEXT,photo_url  TEXT ); ";
    private static final String CREATE_USER_TABLE_QUERY = "CREATE TABLE "+USER_TABLE+"  ( id INTEGER PRIMARY KEY, email  VARCHAR(1000), password  VARCHAR(1000) ); ";

    public BYSQLiteOpenHelper(Context context) {
        super(context,DB_NAME,null,1);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //create business table when database is initialized
        db.execSQL(CREATE_BUSINESS_TABLE_QUERY);
        db.execSQL(CREATE_USER_TABLE_QUERY);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // do nothing for now
    }


    /**
     * Create new Busines
     * @param name of business
     * @param description for business
     * @param website of business
     * @param latitude location of business
     * @param longitude location of business
     * @param facebookURL page for business
     * @param address page for business
     * @param timings page for business
     * @param phoneNumber page for business
     * @return
     */
    public long saveBusiness(String name, String description, String website, double latitude, double longitude, String facebookURL,String address,String timings, String phoneNumber,String photo){
        long id = -1;
        SQLiteDatabase db =getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name",name);
        values.put("description",description);
        values.put("website",website);
        values.put("latitude",latitude);
        values.put("longitude",longitude);
        values.put("facebook_url",facebookURL);
        values.put("address",address);
        values.put("timings",timings);
        values.put("phone_number",phoneNumber);
        values.put("photo_url",photo);
        id = db.insert(BUSINESS_TABLE,null,values);
        db.close();
        return id;
    }

    public long insertBusiness(Business business){

        String name =business.getName();
        String description = business.getDescription();
        String website = business.getWebsite();
        double latitude = business.getLatitude();
        double longitude = business.getLongitude();
        String facebookURL = business.getFacebookURL();
        String address = business.getAddress();
        String timings = business.getTimings();
        String phoneNumber = business.getPhoneNumber();
        String photoURL = business.getPhotoURL();

        return  saveBusiness(name,description,website,latitude,longitude,facebookURL,address,timings,phoneNumber,photoURL);

    }


    /**
     * Update details of existing business
     * @param business
     * @return true if update was successful
     *
     */
    public boolean updateBusiness(Business business){
        Boolean successful = false;
        String name =business.getName();
        String description = business.getDescription();
        String website = business.getWebsite();
        double latitude = business.getLatitude();
        double longitude = business.getLongitude();
        String facebookURL = business.getFacebookURL();
        String address = business.getAddress();
        String timings = business.getTimings();
        String phoneNumber = business.getPhoneNumber();
        String photoURL = business.getPhotoURL();


        Long id = business.getId();
        ContentValues values = new ContentValues();
        values.put("name",name);
        values.put("description",description);
        values.put("website",website);
        values.put("latitude",latitude);
        values.put("longitude",longitude);
        values.put("facebook_url",facebookURL);
        values.put("address",address);
        values.put("timings",timings);
        values.put("phone_number",phoneNumber);
        values.put("photo_url",photoURL);

        SQLiteDatabase db = getWritableDatabase();
        int rowsUpdated = db.update(BUSINESS_TABLE, values,"id = ?",new String[]{""+id});
        successful  = rowsUpdated >0;
        db.close();
        return successful;

    }

    /**
     * Deletes a business record from database
     * @param business
     * @return true if deleted successfully
     */
    public  boolean deleteBusiness(Business business){
        Boolean successful = false;
        Long id = business.getId();

        SQLiteDatabase db = getWritableDatabase();
        int rowsUpdated = db.delete(BUSINESS_TABLE,"id = ?",new String []{""+id});

        successful  = rowsUpdated >0;
        db.close();
        return successful;
    }


    /**
     * List all the business records in database
     * @return Arraylist of objects of Business class
     */
    public ArrayList<Business> listBusinesses(){
        SQLiteDatabase db = getReadableDatabase();
        String[] columns = new String[]{
               "id", "name","description","website","latitude","longitude","facebook_url","address","timings","phone_number","photo_url"
        };

        Cursor cursor =db.query(BUSINESS_TABLE,columns,null,null,null,null,null);
        ArrayList<Business> businesses = new ArrayList<>();

        if(cursor.moveToFirst()){
            do{
                long id = cursor.getLong(0);
                String name = cursor.getString(1);
                String description = cursor.getString(2);
                String website = cursor.getString(3);
                Double latitude = cursor.getDouble(4);
                Double longitude = cursor.getDouble(5);
                String facebookURL = cursor.getString(6);

                String address = cursor.getString(7);
                String timings = cursor.getString(8);
                String phoneNumber = cursor.getString(9);
                String photoURL = cursor.getString(10);

                Business business = new Business();
                business.setId(id);
                business.setName(name);
                business.setDescription(description);
                business.setWebsite(website);
                business.setLatitude(latitude);
                business.setLongitude(longitude);
                business.setFacebookURL(facebookURL);
                business.setAddress(address);
                business.setTimings(timings);
                business.setPhoneNumber(phoneNumber);
                business.setPhotoURL(photoURL);

                businesses.add(business);
            }while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return  businesses;
    }



    public long createUser(String email, String password){
        long id = -1;
        SQLiteDatabase db =getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("email",email);
        values.put("password",password);
        id = db.insert(USER_TABLE,null,values);
        db.close();
        return id;
    }


    public boolean checkIfUserExists(String email){
        boolean userExists = false;
        SQLiteDatabase db = getReadableDatabase();
        String[] columns = new String[]{
                "id", "email"
        };
        String[] selectionArgs = new String[]{
          email
        };

        Cursor cursor =db.query(USER_TABLE,columns,"email = ?",selectionArgs,null,null,null);

        if(cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                userExists = true;
                break;
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return userExists;
    }

    public long login(String email,String password){
        long user = -1L;
        SQLiteDatabase db = getReadableDatabase();
        String[] columns = new String[]{
                "id", "email"
        };
        String[] selectionArgs = new String[]{
                email,password
        };

        Cursor cursor =db.query(USER_TABLE,columns,"email = ? AND password = ?",selectionArgs,null,null,null);

        if(cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                user = id;
                break;
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return user;
    }





}
