package in.businessyoda.businessyoda;

import java.io.Serializable;

/**
 * Created by Ricky Nandra on 02/12/18.
 * External Class
 */

public class Business implements Serializable {
    private Long id;
    private String name;
    private String description;
    private String website;
    private Double longitude,latitude;
    private String facebookURL;

    private String phoneNumber;
    private String timings;
    private String address;
    private String photoURL;



    //Constructors
    public Business(){

    }

    public Business(Long id,String name, String description, String website, Double longitude, Double latitude, String facebookURL) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.website = website;
        this.longitude = longitude;
        this.latitude = latitude;
        this.facebookURL = facebookURL;
    }

    public Business(Long id, String name, String description, String website, Double longitude, Double latitude, String facebookURL, String phoneNumber, String timings, String address, String photoURL) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.website = website;
        this.longitude = longitude;
        this.latitude = latitude;
        this.facebookURL = facebookURL;
        this.phoneNumber = phoneNumber;
        this.timings = timings;
        this.address = address;
        this.photoURL = photoURL;
    }

    //getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public String getFacebookURL() {
        return facebookURL;
    }

    public void setFacebookURL(String facebookURL) {
        this.facebookURL = facebookURL;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getTimings() {
        return timings;
    }

    public void setTimings(String timings) {
        this.timings = timings;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhotoURL() {
        return photoURL;
    }

    public void setPhotoURL(String photoURL) {
        this.photoURL = photoURL;
    }
}

