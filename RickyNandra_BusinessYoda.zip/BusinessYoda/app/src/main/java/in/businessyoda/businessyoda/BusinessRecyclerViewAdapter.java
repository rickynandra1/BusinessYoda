package in.businessyoda.businessyoda;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by Ricky Nandra on 02/12/18.
 */

public class BusinessRecyclerViewAdapter extends RecyclerView.Adapter<BusinessRecyclerViewAdapter.ViewHolder> {
    //data to be shown in the list
    ArrayList<Business> data;

    //listener
    RecylerViewInteractionListener listener;

    //constructor for adapter
    public BusinessRecyclerViewAdapter(ArrayList<Business> businesses,RecylerViewInteractionListener listener) {
        this.data = businesses;
        this.listener = listener;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.business_item,viewGroup,false);
        ViewHolder viewHolder = new BusinessRecyclerViewAdapter.ViewHolder<Business>(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder businessViewHolder, int position) {
      final Business business =  data.get(position);
      String businessName = business.getName()!=null ? business.getName() : "";
      String businessWebsite = business.getWebsite()!=null ? business.getWebsite() : "";

      businessViewHolder.nameTextView.setText(businessName);
      businessViewHolder.websiteTextView.setText(businessWebsite);

        businessViewHolder.viewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Go to new activity to view this business record.
                Intent intent = new Intent(businessViewHolder.itemView.getContext(),ViewBusinessActivity.class);
                intent.putExtra("business",business);
                businessViewHolder.itemView.getContext().startActivity(intent);

            }
        });

        businessViewHolder.editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Go to new activity to edit this business record.
                Intent intent = new Intent(businessViewHolder.itemView.getContext(),EditBusinessActivity.class);
                intent.putExtra("business",business);
                businessViewHolder.itemView.getContext().startActivity(intent);

            }
        });

        businessViewHolder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // delete this record.
                deleteCurrentBussiness(businessViewHolder.itemView.getContext(),business);

            }
        });
    }


    public void  deleteCurrentBussiness(final Context context, final Business business){
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Delete Business")
                .setMessage("Do you really want to delete "+business.getName()+" ?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteBusinessTask(context,business);
                        if(listener!=null){
                            listener.refreshList();
                        }
                        dialog.dismiss();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Do Nothing just dismiss the dialog.
                        dialog.dismiss();
                    }
                })
                .create()
                .show();
    }



    public void  deleteBusinessTask(final Context context,final Business business){
        new AsyncTask<Void,Void,Boolean>(){

            @Override
            protected Boolean doInBackground(Void... voids) {
                BYSQLiteOpenHelper helper= new BYSQLiteOpenHelper(context);
                boolean success=  helper.deleteBusiness(business);
                return success;
            }

            @Override
            protected void onPostExecute(Boolean result) {
                super.onPostExecute(result);
                if(result){
                    Toast.makeText(context, "Deleted Successfully", Toast.LENGTH_SHORT).show();


                }else{
                    Toast.makeText(context, "Unable to Delete Business", Toast.LENGTH_SHORT).show();
                }
            }

        }.execute();
    }


    @Override
    public int getItemCount() {
        return this.data !=null ? this.data.size(): 0;
    }


    public class ViewHolder<Business> extends RecyclerView.ViewHolder{
        public TextView nameTextView;
        public TextView websiteTextView;
        public Button viewButton;
        public Button deleteButton;
        public Button editButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTextView= (TextView) itemView.findViewById(R.id.tv_name);
            websiteTextView= (TextView) itemView.findViewById(R.id.tv_website);
            viewButton= (Button) itemView.findViewById(R.id.bt_view);
            editButton= (Button) itemView.findViewById(R.id.bt_edit);
            deleteButton= (Button) itemView.findViewById(R.id.bt_delete);
        }
    }

    public interface  RecylerViewInteractionListener{
        public void refreshList();
    }
}
