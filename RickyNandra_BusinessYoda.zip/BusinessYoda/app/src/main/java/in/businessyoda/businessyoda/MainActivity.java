package in.businessyoda.businessyoda;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements BusinessRecyclerViewAdapter.RecylerViewInteractionListener {

    private RecyclerView businessesRecyclerView;
    private TextView mNoRecordsTextView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        mNoRecordsTextView = (TextView) findViewById(R.id.tv_no_records);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        businessesRecyclerView = (RecyclerView) findViewById(R.id.rv_businesses);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        businessesRecyclerView.setLayoutManager(layoutManager);


        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,NewBusinessActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        listAllBusinesses();
    }

    public void listAllBusinesses(){
        try{
            BYSQLiteOpenHelper bysqLiteOpenHelper = new BYSQLiteOpenHelper(this);
            ArrayList<Business> businesses = bysqLiteOpenHelper.listBusinesses();
            Log.e("MainActivity","Loaded Businesses Count "+businesses.size());

            BusinessRecyclerViewAdapter adapter = new BusinessRecyclerViewAdapter(businesses,this);
            businessesRecyclerView.setAdapter(adapter);
            if(businesses.size()>0){
                mNoRecordsTextView.setVisibility(View.GONE);
                businessesRecyclerView.setVisibility(View.VISIBLE);

            }else {
                mNoRecordsTextView.setVisibility(View.VISIBLE);
                businessesRecyclerView.setVisibility(View.GONE);
            }

        }catch (Exception exp){
            Log.e("MainActivity","Error while listing businesses "+exp.toString());
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void refreshList() {
        listAllBusinesses();
    }
}
