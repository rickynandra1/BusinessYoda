package in.businessyoda.businessyoda;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class NewBusinessActivity extends AppCompatActivity {
    public static final int CAMERA_REQUEST_CODE = 1;
    EditText nameEditText;
    EditText descriptionEditText;
    EditText websiteEditText;
    EditText latitudeEditText;
    EditText longitudeEditText;
    EditText facebookURLEditText;
    EditText phoneEditText;
    EditText addressEditText;
    EditText timingsEditText;
    ImageButton profileImageButton;

    Button saveButton;
    String mCurrentPhotoPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_business);

        nameEditText = (EditText) findViewById(R.id.et_name);
        descriptionEditText = (EditText) findViewById(R.id.et_description);
        websiteEditText = (EditText) findViewById(R.id.et_website);
        latitudeEditText = (EditText) findViewById(R.id.et_latitude);
        longitudeEditText = (EditText) findViewById(R.id.et_longitude);
        facebookURLEditText = (EditText) findViewById(R.id.et_facebook_url);
        phoneEditText = (EditText) findViewById(R.id.et_phone);
        addressEditText = (EditText) findViewById(R.id.et_address);
        timingsEditText = (EditText) findViewById(R.id.et_timings);
        profileImageButton = (ImageButton) findViewById(R.id.ib_profile);
        saveButton = (Button) findViewById(R.id.bt_save);
        profileImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectImage();
            }
        });

    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case CAMERA_REQUEST_CODE: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission was granted, yay!
                    clickImage();
                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Snackbar.make(addressEditText, "Permission Denied for Camera", Snackbar.LENGTH_LONG).show();
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request.
        }
    }

    private void clickImage() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.MANAGE_DOCUMENTS}, CAMERA_REQUEST_CODE);
            return;
        } else {

            Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            // Ensure that there's a camera activity to handle the intent
            if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                // Create the File where the photo should go
                File photoFile = null;
                try {
                    photoFile = createImageFile();
                } catch (IOException ex) {
                    // Error occurred while creating the File
                    Snackbar.make(profileImageButton, "No Camera Available", Snackbar.LENGTH_LONG).show();

                }
                // Continue only if the File was successfully created
                if (photoFile != null) {
                    Uri photoURI = FileProvider.getUriForFile(this,
                            "in.businessyoda.businessyoda.fileprovider",
                            photoFile);
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                    startActivityForResult(takePictureIntent, 1);
                }
            } else {
                Snackbar.make(profileImageButton, "No Camera Available", Snackbar.LENGTH_LONG).show();
            }
        }
    }

    private void chooseFromGallery() {
        String[] mimeTypes = {"image/jpeg", "image/png"};
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT)
                .setType("image/*")
                .putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
        if (android.os.Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) {
            intent.setAction(Intent.ACTION_GET_CONTENT);
        } else {
            intent.setAction(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
        }

        startActivityForResult(intent, 2);
    }

    private void selectImage() {

        final CharSequence[] options = {"Take Photo", "Choose from Gallery", "Cancel"};
        AlertDialog.Builder builder = new AlertDialog.Builder(NewBusinessActivity.this);
        builder.setTitle("Choose Photo!");
        builder.setItems(options, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (options[item].equals("Take Photo")) {
                    clickImage();
                } else if (options[item].equals("Choose from Gallery")) {
                    chooseFromGallery();
                } else if (options[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = image.getAbsolutePath();
        return image;
    }



    protected void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent) {
        //  super.onActivityResult(requestCode, resultCode, imageReturnedIntent);
        switch (requestCode) {
            case 1:
                if (resultCode == RESULT_OK) {
                    profileImageButton.setImageURI(Uri.parse(mCurrentPhotoPath));
                }

                break;
            case 2:
                if (resultCode == RESULT_OK) {
                    Uri selectedImage = imageReturnedIntent.getData();
                    mCurrentPhotoPath = selectedImage.toString();
                    profileImageButton.setImageURI(selectedImage);
                }
                break;
        }
    }


    public String validateInput(Business business){
        String result = null;

        String name = business.getName();
        String description = business.getDescription();
        String website = business.getWebsite();
        String facebookURL = business.getFacebookURL();
        String address = business.getAddress();
        String phoneNumber = business.getPhoneNumber();
        String timings = business.getTimings();

        Double latitude  = business.getLatitude();
        Double longitude  = business.getLongitude();

        if(name!=null && name.isEmpty()){
            return "Name is Required";
        }
        if(description!=null && description.isEmpty()){
            return "Description is Required";
        }
        if(facebookURL!=null && facebookURL.isEmpty()){
            return "Facebook URL is Required";
        }

        if(address!=null && address.isEmpty()){
            return "Address is Required";
        }

        if(website!=null && website.isEmpty()){
            return "Website is Required";
        }

        if(phoneNumber!=null && phoneNumber.isEmpty()){
            return "Phone is Required";
        }

        if(timings!=null && timings.isEmpty()){
            return "Timings are Required";
        }

        return result;
    }



    public void onSaveClick(final View view) {
        //Save New Business
        final String name = nameEditText.getText().toString();
        final String description = descriptionEditText.getText().toString();
        final String website = websiteEditText.getText().toString();

        final String facebookURL = facebookURLEditText.getText().toString();
        String latitudeString = latitudeEditText.getText().toString();
        String longitudeString = longitudeEditText.getText().toString();

        final String address = addressEditText.getText().toString();
        final String timings = timingsEditText.getText().toString();
        final String phoneNumber = phoneEditText.getText().toString();


        Double latitude = -1.0, longitude = -1.0;
        try {
            latitude = Double.parseDouble(latitudeString);
            longitude = Double.parseDouble(longitudeString);
        } catch (Exception exp) {
            Log.e("NewBusinessActivity", "Error in parsing lat/long");
        }

        Business business = new Business();
        business.setName(name);
        business.setDescription(description);
        business.setWebsite(website);
        business.setFacebookURL(facebookURL);
        business.setLatitude(Double.parseDouble(latitudeString));
        business.setLongitude(Double.parseDouble(longitudeString));
        business.setAddress(address);
        business.setTimings(timings);
        business.setPhoneNumber(phoneNumber);
        business.setPhotoURL(mCurrentPhotoPath);
        String validationResult = validateInput(business);

        if(validationResult!=null){
            Snackbar.make(saveButton,"Error: "+validationResult,Snackbar.LENGTH_LONG).show();
            return;
        }else {

        }
        final BYSQLiteOpenHelper bysqLiteOpenHelper = new BYSQLiteOpenHelper(this);
        try {
            final Double finalLatitude = latitude;
            final Double finalLongitude = longitude;
            new AsyncTask<Void, Void, Void>() {

                @Override
                protected Void doInBackground(Void... voids) {
                    Log.e("NewBusiness", "Photo URI " + mCurrentPhotoPath);
                    bysqLiteOpenHelper.saveBusiness(name, description, website, finalLatitude, finalLongitude, facebookURL, address, timings, phoneNumber, mCurrentPhotoPath);
                    return null;
                }

                @Override
                protected void onPostExecute(Void aVoid) {
                    super.onPostExecute(aVoid);
                    Snackbar.make(view, "New Business Saved", Snackbar.LENGTH_LONG).show();
                    clear();

                }
            }.execute();
        } catch (Exception exp) {
            Log.e("NewBusinessActivity", " Save Business Error " + exp);
        }

    }

    public void clear() {
        nameEditText.setText("");
        descriptionEditText.setText("");
        websiteEditText.setText("");
        latitudeEditText.setText("");
        longitudeEditText.setText("");
        facebookURLEditText.setText("");
        addressEditText.setText("");
        timingsEditText.setText("");
        phoneEditText.setText("");
    }


}
