package in.businessyoda.businessyoda;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SignupActivity extends AppCompatActivity {

    EditText emailEditText;
    EditText passwordEditText;
    Button signupButton;
    TextView loginTextView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        emailEditText = (EditText) findViewById(R.id.input_email);
        passwordEditText = (EditText) findViewById(R.id.input_password);
        signupButton = (Button) findViewById(R.id.btn_signup);
        loginTextView = (TextView) findViewById(R.id.link_login);


        signupButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                signup();
            }
        });

        loginTextView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // Start the Signup activity
             finish();
            }
        });
    }

    private void signup(){
        if (!validate()) {
            onSignupFailed();
            return;
        }

        signupButton.setEnabled(false);

        final ProgressDialog progressDialog = new ProgressDialog(SignupActivity.this,
                R.style.AppTheme_PopupOverlay);
        progressDialog.setIndeterminate(true);
        progressDialog.setMessage("Creating Account...");
        progressDialog.show();

        final String email = emailEditText.getText().toString();
        final String password = passwordEditText.getText().toString();
        // Signup

        final BYSQLiteOpenHelper bysqLiteOpenHelper = new BYSQLiteOpenHelper(this);
        try{


            new AsyncTask<Void,Void,Long>(){

                @Override
                protected Long doInBackground(Void... voids) {
                    boolean userExists= bysqLiteOpenHelper.checkIfUserExists(email);
                    if(userExists){
                        return -1L;
                    }
                    return bysqLiteOpenHelper.createUser(email,password);

                }

                @Override
                protected void onPostExecute(Long result) {
                    super.onPostExecute(result);
                    progressDialog.dismiss();
                    if(result!=-1){
                        Snackbar.make(signupButton, "User Created", Snackbar.LENGTH_LONG).show();
                        onSignupSuccess();
                    }else{
                        Snackbar.make(signupButton, "User Already Exist", Snackbar.LENGTH_LONG).show();
                        onSignupFailed();
                    }

                }
            }.execute();
        }catch (Exception exp){
            Log.e("Signup"," Signup Error "+exp);
        }

    }

    public void onSignupSuccess() {
        signupButton.setEnabled(true);
        setResult(RESULT_OK, null);
        finish();
    }

    public void onSignupFailed() {
      //  Snackbar.make(signupButton, "Login failed", Snackbar.LENGTH_LONG).show();
        signupButton.setEnabled(true);
    }


    public boolean validate() {
        boolean valid = true;

        String email = emailEditText.getText().toString();
        String password = passwordEditText.getText().toString();



        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailEditText.setError("Enter a valid email address");
            valid = false;
        } else {
            emailEditText.setError(null);
        }

        if (password.isEmpty() || password.length() < 4 || password.length() > 10) {
            passwordEditText.setError("between 4 and 10 alphanumeric characters");
            valid = false;
        } else {
            passwordEditText.setError(null);
        }

        return valid;
    }
}
