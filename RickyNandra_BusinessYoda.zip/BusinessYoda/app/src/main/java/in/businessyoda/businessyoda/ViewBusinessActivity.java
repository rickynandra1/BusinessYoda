package in.businessyoda.businessyoda;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;

public class ViewBusinessActivity extends AppCompatActivity {

    private ImageView profileImageView;

    private TextView nameTextView;
    private TextView descriptionTextView;
    private TextView websiteTextView;
    private TextView facebookURLTextView;
    private TextView locationTextView;

    private TextView addressTextView;
    private TextView phoneTextView;
    private TextView timingsTextView;

    private Business business;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_business);
        findViews();
        loadValues();
    }

    private void findViews() {
        nameTextView = (TextView) findViewById(R.id.tv_name);
        descriptionTextView = (TextView) findViewById(R.id.tv_description);
        websiteTextView = (TextView) findViewById(R.id.tv_website);
        facebookURLTextView = (TextView) findViewById(R.id.tv_facebook_url);
        locationTextView = (TextView) findViewById(R.id.tv_location);

        addressTextView = (TextView) findViewById(R.id.tv_address);
        phoneTextView = (TextView) findViewById(R.id.tv_phone);
        timingsTextView = (TextView) findViewById(R.id.tv_timings);

        profileImageView = (ImageView) findViewById(R.id.iv_profile);

    }

    private void loadValues() {
        Intent intent =getIntent();

        //business was passed as an extra to this activity from previous activity
        if(intent.hasExtra("business")){
            Serializable serializable = intent.getSerializableExtra("business");

            //serializable must be object of type business
            if(serializable instanceof Business){
                business = (Business) serializable;

                String name = business.getName();
                String description = business.getDescription();
                String website = business.getWebsite();
                String facebookURL = business.getFacebookURL();

                Double latitude  = business.getLatitude();
                Double longitude  = business.getLongitude();
                String locationString  = latitude + " , "+longitude;

                String address = business.getAddress();
                String phone = business.getPhoneNumber();
                String timings = business.getTimings();

                String photoURL = business.getPhotoURL();

                nameTextView.setText(name);
                descriptionTextView.setText(description);
                websiteTextView.setText(website);
                facebookURLTextView.setText(facebookURL);
                locationTextView.setText(locationString);
                addressTextView.setText(address);
                phoneTextView.setText(phone);
                timingsTextView.setText(timings);

                if(photoURL!=null){
                    try {
                        profileImageView.setImageURI(Uri.parse(photoURL));
                        // profileImageView.setImageBitmap(MediaStore.Images.Media.getBitmap(this.getContentResolver(), Uri.parse(photoURL)));
                        Log.e("ViewBusiness","Heere is image "+photoURL);
                    }catch (Exception exp){
                        Log.e("ViewBusiness","Unable to load image");
                    }
                }

            }else{
                Toast.makeText(this, "Invalid Object Passed.", Toast.LENGTH_SHORT).show();
                finish();
            }
        }else{
            Toast.makeText(this, "No Business Found.", Toast.LENGTH_SHORT).show();
            finish();
        }
    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        return super.onOptionsItemSelected(item);
    }
}

